import React from 'react'
import Logo from '../Mainpage/Logo'
import Navbar from '../Mainpage/Navbar'

function Main() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <div className='bg bg-info'>
                <h1 className='text text-light bg bg-secondary' style={{ paddingLeft: '100px' }}>Home Page</h1>
            </div>

            <img src='Images/main.jpg' alt='main' style={{ width: "100%", margin: '0px' }}></img>
        </>
    )
}

export default Main