import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
import Body from '../Mainpage/Body';
function Jobapplication() {
    return (
        <>
            <form>
                <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
                <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />

                <Header name1="HRM System" name2="Job Application Form" />

                <div className='row'>
                    <div className='col-lg-2'>
                        <Body label2="Job Applied For" label3="Name" label4="FatherName" label5="CNIC" label6="Marital Status" label7="Gender" label8="Religion" label9="Date ofDirth" label10="Permanent Address" label11="Provience" label12="City" label13="Contact " label14="Mobile Number" label15="Email Address" />

                    </div>
                    <div className='col-lg-6 mt-3'>
                        <label for="cars">Choose a car:</label>

                        <select id="cars">
                            <option value="volvo">Volvo</option>
                            <option value="saab">Saab</option>
                            <option value="vw">VW</option>
                            <option value="audi">Audi</option>
                        </select><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <div className='row'>
                            <div className='col-lg-2'>
                                <input type="radio" id="html" name="fav_language" value="HTML"></input>
                                <label for="Married">Married</label><br />

                            </div>
                            <div className='col-lg-2'>
                                <input type="radio" id="html" name="fav_language" value="HTML"></input>
                                <label for="Married">Single</label><br />

                            </div>
                            <div className='col-lg-2'>
                                <input type="radio" id="html" name="fav_language" value="HTML"></input>
                                <label for="Married">Other</label><br />

                            </div>

                        </div>

                        <div className='row'>
                            <div className='col-lg-2'>
                                <input type="radio" id="html" name="fav_language" value="HTML"></input>
                                <label for="Married">Male</label><br />

                            </div>
                            <div className='col-lg-2'>
                                <input type="radio" id="html" name="fav_language" value="HTML"></input>
                                <label for="Married">Female</label><br />

                            </div>
                            <div className='col-lg-2'>
                                <input type="radio" id="html" name="fav_language" value="HTML"></input>
                                <label for="Married">Other</label><br />

                            </div>

                        </div>
                        <div className='row'>
                            <div className='col-lg-2'>
                                <input type="radio" id="css" name="fav_language" value="Muslim"></input>
                                <label for="Married">Muslim</label><br />

                            </div>
                            <div className='col-lg-4'>
                                <input type="radio" id="css" name="fav_language" value="Non-Muslim"></input>
                                <label for="Married">Non-Muslim</label><br />

                            </div>


                        </div>


                        <input type={'text'}></input><br />
                        <textarea style={{ height: "40px" }}></textarea><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />




                    </div>
                    <div className='col-lg-2'>
                        <table border={1}>
                            <tr>
                                <th>
                                    <label>Applicant ID</label>
                                </th>
                                <th>
                                    <input type={"text"}></input>
                                </th>
                            </tr>
                        </table><br /><br />
                        <label>Photo</label>
                        <div class="card " >
                            <img class="card-img-top" src="Images/image1.png" alt="Card image cap" style={{ height: "200px" }} />
                            <label for="formFileLg" class="form-label">File Format </label>
                            <input class="form-control form-control-sm" id="formFileLg" type="file" />

                        </div>

                    </div>

                </div>
                <button type="button" class="btn btn-success">Proceed Next</button>&nbsp;
                <button type="button" class="btn btn-info">Exit</button>&nbsp;

            </form>

        </>
    )
}

export default Jobapplication