import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';

function JobAdvertisement() {
    return (
        <>
            <form>
                <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
                <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />

                <Header name1="HRM System" name2="Job Advertisement Form" />
                <div div className='container'>
                    <div className='row'>
                        <div className='col-lg-8'>
                            <label>Job Id</label>
                            <input type={'text'}></input><br />
                            <label>Job Title</label>
                            <input step={{ width: "700px" }} type={'text'}></input><br />
                            <label>Division</label>
                            <select name="cars" id="cars">
                                <option value="volvo">Volvo</option>
                                <option value="saab">Saab</option>
                                <option value="opel">Opel</option>
                                <option value="audi">Audi</option>
                            </select><br />
                            <label>Location</label>
                            <select name="cars" id="cars">
                                <option value="volvo">Volvo</option>
                                <option value="saab">Saab</option>
                                <option value="opel">Opel</option>
                                <option value="audi">Audi</option>
                            </select><br />
                            <label>Unit</label>
                            <input type={'text'}></input><br />
                            <label>Department</label>
                            <input type={'text'}></input><br /><br />
                            <label>Required Experience</label><br />
                            <label>Minimum</label>
                            <input type={'number'}></input>
                            <select name="Select Experience time" id="cars">
                                <option value="volvo">Month</option>
                                <option value="saab">Year</option>
                            </select><br />
                            <label>Maximum</label>
                            <input type={'number'}></input>
                            <select name="Select Experience time" id="cars">
                                <option value="volvo">Month</option>
                                <option value="saab">Year</option>
                            </select><br />
                            <label>Qualification</label><br />
                            <textarea></textarea><br />
                            <label>Details</label><br />
                            <textarea></textarea><br />



                        </div>
                        <div className='col-lg-4'>
                            <label>No of Jobs</label><input type={'number'}></input>
                            <label>Job status</label>
                            <select name="Select Experience time" id="cars">
                                <option value="volvo">Open</option>
                                <option value="saab">Close</option>
                            </select><br />
                            <label>Closing Date</label><input type={'date'}></input>
                            <br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
                            <label>Posted By</label><input type={'text'}></input><br />
                            <label>Designation</label><input type={'text'}></input><br />
                        </div>

                    </div>
                    <button type="button" class="btn btn-success">Save</button>&nbsp;
                    <button type="button" class="btn btn-primary">New </button>&nbsp;
                    <button type="button" class="btn btn-info">Exit</button>&nbsp;
                </div>

            </form>


        </>
    )
}

export default JobAdvertisement