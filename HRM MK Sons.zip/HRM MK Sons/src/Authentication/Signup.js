import { React, useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'

function Signup() {

    const [fname, setfname] = useState()
    const [lname, setlname] = useState()
    const [email, setemail] = useState()
    const [password, setpassword] = useState()
    const [confpassword, setconfpassword] = useState()


    const onbtnclick = () => {

        axios.post(`http://127.0.0.1:5000/api/users/Login`, {
            fname: fname,
            lname: lname,
            email: email,
            password: password,
            confpassword: confpassword,

        }).then((res) => {
            console.log(res.data)
            alert("Message was sent Successfully")
        }).catch((err) => {
            console.log(err)
        })

    }
    return (
        <>
            <div class='container' style={{ width: '700px' }}>
                <label for="exampleInputpassword1">First name</label>
                <input onChange={(e) => setfname(e.target.value)} type="text" name="fname" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter a First name"></input>
                <label for="exampleInputpassword1">Last name</label>
                <input onChange={(e) => setlname(e.target.value)} type="text" name="lname" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter a Last name"></input>
                <label for="exampleInputpassword1">Enter Email</label>
                <input onChange={(e) => setemail(e.target.value)} type="text" name="email" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter  Email"></input>



                <label for="exampleInputpassword1">Password</label>
                <input onChange={(e) => setpassword(e.target.value)} type="password" name="password" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter password"></input>
                <label for="exampleInputpassword1">Confirm Password</label>
                <input onChange={(e) => setconfpassword(e.target.value)} type="password" name="confpassword" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter password"></input>





                <button onClick={() => onbtnclick()} type="button" class="btn my-3 btn-primary">Register</button>

                <button onClick={() => onbtnclick()} type="button" class=" btn-primary" > <Link to={'/'} className='btn btn-primary'>Click to Login</Link></button>
            </div>
        </>
    )
}

export default Signup