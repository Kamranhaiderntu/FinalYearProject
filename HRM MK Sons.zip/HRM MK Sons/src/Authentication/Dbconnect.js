const { Client } = require('pg');



async function connectDB(user, dbname, pass, table) {
    const client = new Client({
        user: user,
        database: dbname,
        password: pass,
        host: 'localhost',
        port: 5432
    })
    await client.connect();

    let sql = `INSERT INTO ${table} (name,email,age,dob) VALUES("hasham","hasham@gmail.com",35,"2023-01-20");`
    let sql2 = `INSERT INTO students (name,email,age,dob) VALUES('Hasham','kami123@gmail.com',20,'2023-01-20');
    `
    try {
        await client.query(sql2);
        console.log("Query Inserted");
    } catch (error) {
        console.log("Query not Inserted");
        console.log(error);
    }
    client.end();

}
connectDB('postgres', 'students', '434339388', 'students')
module.exports = { connectDB }
