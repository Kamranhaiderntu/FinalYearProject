import { useState } from 'react';
import axios from 'axios'
import { Link } from 'react-router-dom';

function Login() {
    const [name, setname] = useState()
    const [password, setpassword] = useState()


    const onbtnclick = () => {

        axios.post(`http://127.0.0.1:5000/api/users/Login`, {
            name: name,
            password: password,

        }).then((res) => {
            console.log(res.data)
            alert("Message was sent Successfully")
        }).catch((err) => {
            console.log(err)
        })

    }

    return (
        <div class='container' style={{ width: '700px' }}>
            <label for="exampleInputpassword1">Name</label>
            <input onChange={(e) => setname(e.target.value)} type="text" name="name" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter a Username"></input>

            <label for="exampleInputpassword1">password address</label>
            <input onChange={(e) => setpassword(e.target.value)} type="password" name="password" class="form-control" id="exampleInputpassword1" aria-describedby="passwordHelp" placeholder="Enter password"></input>





            <button onClick={() => onbtnclick()} type="button" class="btn my-3  btn-primary">Sign In</button>

            <button onClick={() => onbtnclick()} type="button" class="btn my-3  btn-primary">
                <Link to={'/signup'} class="btn-primary">Sign Up</Link></button>
        </div>
    );
}

export default Login;