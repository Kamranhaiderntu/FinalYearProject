import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';


function InOutPF() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />

            <Header name1="HRM System" name2="&emsp;&emsp;&emsp;In Out Policy Form" />
            <div>
                <form className='border' style={{ borderRadius: '15px', paddingTop: '3px' }}>
                    <div className='container-fluid'>
                        <div className='row' style={{ justifyContent: 'space-between' }}>
                            <div className='col-auto'>
                                <p className='form-inline p-1' style={{ margin: '0px', padding: '0px' }}>
                                    <label>Division</label>
                                    <input type={'text'} className='form-control p-2' style={{ marginLeft: '75px', marginBottom: '15px', width: '360px' }}></input><br />
                                </p>
                                <p className='form-inline'>
                                    <label>Unit</label>
                                    <input type={'text'} className='form-control' style={{ marginLeft: '105px', width: '360px' }}></input><br />
                                </p>
                                <p className='form-inline'>
                                    <label>Employment Type</label>
                                    <input type={'text'} style={{ width: '360px' }} className='form-control m-2'></input>
                                </p>

                            </div>
                            <div className='col-lg-auto'>
                                <p className='form-inline' style={{ width: '400px', margin: '10px', padding: '0px' }}><label>Shift</label><select style={{ marginLeft: '95px', marginRight: '0px', marginBottom: '7px' }} className='form-control' name="Shift">
                                    <option value="A">A</option>
                                    <option value="B">B</option>
                                    <option value="C">C</option>
                                </select></p>
                                <p className='form-inline'><label>OverTime Allowed</label><select className='form-control' name="Shift" style={{ marginLeft: '10px', marginRight: '0px' }}>
                                    <option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select></p>
                                <p className='form-inline'>
                                    <label>Policy Type</label>
                                    <input type={'text'} style={{ marginLeft: '60px', marginRight: '0px' }} className='form-control'></input>
                                </p>
                            </div>
                            <div className='col-auto'>
                                <p className='form-inline m-2'>
                                    <label>Policy No</label>
                                    <input type={'text'} disabled style={{ marginLeft: '5px' }}></input>
                                </p>
                                <p className='form-inline m-2' style={{ padding: '4px' }}>
                                    <label>Policy Status</label>
                                    <select className='form-control' name="Policy Status" style={{ marginLeft: '5px' }}>
                                        <option value="Yes">Active</option>
                                        <option value="No">In Active</option>
                                    </select>
                                </p>
                                <p className='form-inline'>
                                    <label>Applied on <br />Manager and Above</label>
                                    <input type={'text'} className='form-control' style={{ marginLeft: '5px', width: '100px' }}></input>
                                </p>
                            </div>
                            <div className='col-auto'>
                                <p className='form-inline'>
                                    <labrl>Effective Date</labrl>
                                    <input className='form-control' type={'date'}></input>
                                </p>
                                <p className='form-inline'>
                                    <labrl>Expire Date</labrl>
                                    <input className='form-control m-2' style={{ width: '140px' }} type={'date'}></input>
                                </p>
                            </div>
                        </div>
                        <div className='row'>
                            <div style={{ display: 'flex', justifyContent: 'space-around', flexDirection: 'row' }}>
                                <p>Duty Start & End time</p>
                                <p>Half & Hour Start Time</p>
                                <p>Half & Hour End Time</p>
                                <p>Allow Half & Hour </p>
                                <p>Half and Hour Mints Range</p>
                                <p>Allow Half Day</p>
                                <p>Half Day Mints Range</p>
                            </div>
                            <div className='form-inline' style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                <p style={{ marginTop: '9px', marginLeft: '30px' }}>
                                    <input className='form-control' type={'text'} style={{ width: '80px' }}></input> -
                                    <input className='form-control' type={'text'} style={{ width: '80px' }}></input>
                                </p>
                                <input className='form-control' type={'text'} style={{ margin: '0px', padding: '0px' }}></input>
                                <input className='form-control' type={'text'}></input>
                                <input className='form-control' type={'text'}></input>
                                <p style={{ marginTop: '9px' }}>
                                    <input className='form-control' type={'text'} style={{ width: '80px' }}></input> -
                                    <input className='form-control' type={'text'} style={{ width: '80px' }}></input>
                                </p>
                                <input className='form-control' type={'text'}></input>
                                <p style={{ marginTop: '9px', marginRight: '20px' }}>
                                    <input className='form-control' type={'text'} style={{ width: '80px' }}></input> -
                                    <input className='form-control' type={'text'} style={{ width: '80px' }}></input>
                                </p>

                            </div>
                        </div>
                    </div>
                </form>
                <form className='border' style={{ borderRadius: '15px', marginTop: '5px', padding: '60px' }}>
                    <div className='container-fluid'>
                        <div className='row'>
                            <div style={{ justifyContent: 'space-around', flexDirection: 'row', display: 'flex' }}>
                                <label>Sr #</label>
                                <label>Start In Time</label><p>&ensp;</p>
                                <label>End In Time</label><p>&ensp;</p>
                                <label>Start Out Time</label><p>&ensp;</p>
                                <label>End Out Time</label><p><p>&ensp;</p></p>
                                <label>Duty Timing Minutes Range</label><p>&ensp;</p>
                                <label>Policy Status</label><p>&ensp;</p>
                                <label>Day Status</label><p>&ensp;</p>
                                <label>Half Day</label><p>&ensp;</p>
                                <label>Half and Hour</label>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>
                            <div style={{ justifyContent: 'space-between', flexDirection: 'row', display: 'flex' }}>
                                <input className='form-control' type={'text'} style={{ width: '60px', backgroundColor: 'skyblue' }}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                                <input className='form-control' style={{ width: '135px' }} type={'text'}></input>
                            </div>

                        </div>
                    </div>
                </form>
                <form className='border' style={{ borderRadius: '15px', marginTop: '5px', display: 'flex', alignItems: 'flex-end', justifyContent: 'flex-end' }}>
                    <div className='m-3'>
                        <button type="button" class="btn btn-success">Save</button>&nbsp;
                        <button type="button" class="btn btn-info">Exit</button>&emsp;&emsp;&emsp;&emsp;
                    </div>

                </form>
            </div>
        </>
    )
}

export default InOutPF