import React from 'react'
import './style.css'
function Application() {
    return (
        <>
            <div className='container'>
                <div>
                    <div><label style={{ paddingLeft: '150px' }}>Application Description</label>
                        <label style={{ paddingLeft: '150px' }}>Menu Description</label>
                        <label style={{ paddingLeft: '365px' }}>Verfiy</label></div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div><br />
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div><br />
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div><br />
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div><br />

                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div>
                    <div id='input-group'>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '300px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '400px' }}></input>
                        <input type={'text'} className='form-control' style={{ width: '130px' }}></input>
                        <input type={'checkbox'} className='m-2' style={{ width: '26px' }}></input>
                    </div><br />
                </div>
            </div>
        </>
    )
}

export default Application