import React from 'react';
import { useState } from 'react';
import Header from '../../Mainpage/Header';
import Logo from '../../Mainpage/Logo';
import Navbar from '../../Mainpage/Navbar';
import Application from './Application';
import './style.css';
import User from './User';


function ApplicationRegForm() {
    const [toggleState, setToggleState] = useState(1);

    const toggleTab = (index) => {
        setToggleState(index);
    };
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header className="bg bg-primary" name1="Window 1" />
            <div className="container-fluid">
                <div className="bloc-tabs">
                    <button
                        className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
                        onClick={() => toggleTab(1)}
                    >
                        Application Registration Form
                    </button>
                    <button
                        className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
                        onClick={() => toggleTab(2)}
                    >
                        User Registration Form
                    </button>
                </div>

                <div className="content-tabs">
                    <div className={toggleState === 1 ? "content  active-content" : "content"} >

                        <div className='container-fluid bg bg-light'>
                            <div className='px-5 py-2' style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', backgroundColor: 'white', borderRadius: '10px' }}>
                                <h2>Application Registration</h2>
                                <p><b>TN#: HRM-0412</b></p>

                            </div>
                            <Application />
                        </div>
                    </div>

                    <div className={toggleState === 2 ? "content  active-content" : "content"} >
                        <div className='container-fluid bg bg-light'>
                            <div className='px-3' style={{ display: 'flex', flexDirection: 'row', justifyContent: 'space-between', backgroundColor: 'white', borderRadius: '10px' }}>
                                <h2>User Registration</h2>
                                <p><b>TN#: HRM-0412</b></p>
                            </div>
                            <User />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
};

export default ApplicationRegForm