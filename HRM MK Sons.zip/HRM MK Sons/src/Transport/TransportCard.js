import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function TransportCard() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Transport Card Issurance Form" />
            <form>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-4'>
                            <label>Emp code</label><br />
                            <label>Emp Namme</label><br />
                            <label>unit</label><br />
                            <label>Department</label><br />
                            <label>Section</label><br />
                            <label>Designation</label><br />
                            <label>Issue Date</label><br />

                        </div>
                        <div className='col-lg-4'>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'date'}></input><br />

                        </div>
                        <div className='col-lg-4'>
                            <div class="card" style={{ width: "18rem", height: '100px' }}>

                            </div>

                        </div>



                    </div>

                </div>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-2'>
                            <label>Region Title</label><br />
                            <label>Route ID</label><br />
                            <label>Seating Number</label><br />

                        </div>
                        <div className='col-lg-2'>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'number'}></input><br />

                        </div>
                        <div className='col-lg-2'>
                            <label>Region Title</label><br />
                            <label>License No</label><br />
                            <label>Seating Number</label><br />

                        </div>
                        <div className='col-lg-2'>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'number'}></input><br />

                        </div>
                        <div className='col-lg-2'>
                            <label>Region Detail</label><br />
                            <label>Model</label><br />
                            <label>Total Seating Capacity</label><br />
                            <label>Total Allocated seat</label><br />
                            <label>less Allocation</label><br />

                        </div>
                        <div className='col-lg-2'>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />


                        </div>



                    </div>

                </div>
                <button type="button" class="btn btn-outline-primary mt-3">Save</button>
                <button type="button" class="btn btn-outline-primary mt-3">Clear</button>
                <button type="button" class="btn btn-outline-primary mt-3">Exit</button>
            </form>
        </>

    )
}

export default TransportCard