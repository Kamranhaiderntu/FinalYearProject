import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function MessDeducationMember() {
  return (
    <>
      <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
      <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
      <Header name1="HRM System" name2="Mess Deducation Member Form" />
      <form>
        <div className='container'>
          <label>From Date</label><br />
          <input type={'date'}></input><br />
          <label>TO Date</label><br />
          <input type={'date'}></input><br />

          <button>Save</button>
          <button>Clear</button>

        </div>


      </form>
    </>
  )
}

export default MessDeducationMember