import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function MessMembership() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Mess Membership form" />
            <form>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-4'>
                            <label>Date</label><br />
                            <label>Employee Code</label><br />
                            <label>Name</label><br />
                            <label>Designation</label><br />
                            <label>Division</label><br />
                            <label>Unit</label><br />
                            <label>Department</label><br />

                        </div>
                        <div className='col-lg-4'>
                            <input type={'date'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />

                        </div>
                        <div className='col-lg-4'>
                            <div class="card" style={{ width: '10rem', height: '200px' }}>
                                <div class="card-body">

                                </div>
                            </div>

                        </div>

                    </div>

                </div>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-2'>
                            <h6>Joining Date</h6>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />

                        </div>
                        <div className='col-lg-2'>
                            <h6>Leaving Date</h6>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />

                        </div>
                        <div className='col-lg-2'>
                            <h6>Mess Type</h6>
                            <select>
                                <option>Type</option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />

                        </div>
                        <div className='col-lg-2'>
                            <h6>Charge</h6>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />

                        </div>
                        <div className='col-lg-2'>
                            <h6>Status</h6>
                            <select>
                                <option>Type</option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />
                            <select>
                                <option></option>
                            </select><br />

                        </div>

                    </div>

                </div>

                <button type="button" class="btn btn-outline-primary mt-3">Save</button>
                <button type="button" class="btn btn-outline-primary mt-3">Clear</button>
                <button type="button" class="btn btn-outline-primary mt-3">Exit</button>
            </form>
        </>
    )
}

export default MessMembership