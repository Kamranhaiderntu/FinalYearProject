import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';

function UnitOfMeasure() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Unit of Measure Registration Form" />
            <form>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-4'>
                            <label><h4>Unit of Measure Description</h4></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                        </div>
                        <div className='col-lg-4'>
                            <label><h4>Short Description</h4></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                        </div>
                        <div className='col-lg-2'>
                            <label><h4>Feeding Date</h4></label>
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                            <input type={'date'} /><br />
                        </div>
                        <div className='col-lg-2' style={{ marginTop: '45px' }}>
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                        </div>
                    </div>
                </div>
                <input type={'button'} value='Exit' className='px-5' style={{ marginLeft: '80%', marginTop: '10px' }} />
            </form>
        </>
    )
}

export default UnitOfMeasure