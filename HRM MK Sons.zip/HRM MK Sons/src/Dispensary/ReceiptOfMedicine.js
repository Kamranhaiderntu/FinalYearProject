import React from 'react'
import Navbar from '../Mainpage/Navbar'
import Header from '../Mainpage/Header'
import Logo from '../Mainpage/Logo'

function ReceiptOfMedicine() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Medicine  Registration Form" />
            <form>
                <div className='container'>
                    <h4>Receipt ID</h4>
                    <input type={'text'}></input>
                    <h4>Date</h4>
                    <input type={'date'}></input>
                    <div className='row'>
                        <div className='col-lg-2'>
                            <label><h4>Sr #</h4></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />

                        </div>
                        <div className='col-lg-2'>
                            <label><h4>Item Code</h4></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />

                        </div>
                        <div className='col-lg-2'>
                            <label><h5>Medicine Name</h5></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />

                        </div>
                        <div className='col-lg-2'>
                            <label><h4>Quantity</h4></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />

                        </div>
                        <div className='col-lg-2'>
                            <label><h4>Rates</h4></label>
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />
                            <input type={'text'} /><br />

                        </div>
                        <div className='col-lg-2' style={{ marginTop: '45px' }}>
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />
                            <input type={'button'} style={{ width: '100px' }} value="Save" /><br />

                        </div>
                        <div className='col-lg-12 my-5'>
                            <input type={'button'} style={{ marginLeft: '70%', width: '80px' }} value='save' /> <input type={'button'} style={{ width: '80px' }} value='Exit' />
                        </div>

                    </div>
                </div>
            </form>
        </>
    )
}

export default ReceiptOfMedicine