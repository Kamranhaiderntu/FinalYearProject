import React from 'react'
import Logo from '../Mainpage/Logo'
import Header from '../Mainpage/Header'
import Navbar from '../Mainpage/Navbar'
function LoanRequestForm() {
    return (
        <>
            <div>
                <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
                <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
                <div style={{ backgroundColor: 'skyblue' }}>
                    <Header name1="HRM System" name2="&emsp;&emsp;&emsp;Loan Request Form" name3="Loan Information" />
                    <h6>&emsp;&emsp;&emsp;&emsp;&emsp;Loan Information</h6>
                </div>
                <form>
                    <div className='container-fluid'>
                        <div className='row'>
                            <div className='col-lg-9'>
                                <div className='container'>
                                    <div className='row'>
                                        <div className='col-lg-7 bg-light'>
                                            <p className='form-inline'>
                                                <label>Apply Date</label>&emsp;
                                                <input style={{ marginLeft: '55px' }} type={'date'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Application #</label>&emsp;
                                                <input style={{ marginLeft: '42px' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Employee Code</label>&emsp;
                                                <input style={{ marginLeft: '27px', width: '70%' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Employee Name</label>&emsp;
                                                <input style={{ marginLeft: '28px', width: '70%' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Unit</label>&emsp;
                                                <input style={{ marginLeft: '112px', width: '70%' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Department</label>&emsp;
                                                <input style={{ marginLeft: '57px', width: '70%' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Section</label>&emsp;
                                                <input style={{ marginLeft: '90px', width: '70%' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Designation</label>&emsp;
                                                <input style={{ marginLeft: '60px', width: '70%' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Date of Appointment</label>&emsp;
                                                <input type={'date'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Total Gratuity</label>&emsp;
                                                <input style={{ marginLeft: '50px' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Loan Amount</label>&emsp;
                                                <input style={{ marginLeft: '50px' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>Monthly INstallment</label>&emsp;
                                                <input type={'text'} className='form-control'></input>
                                            </p>
                                        </div>
                                        <div className='col-lg-5 bg-light'>
                                            <p style={{ display: 'flex', alignItems: 'start', padding: '10px' }}>
                                                <input type={'text'} className='form-control m-2'></input>
                                                <img class="card-img-top" src='Images/image1.png' alt="Card cap" style={{ height: "200px", width: '200px' }} />
                                            </p><br /><br /><br /><br /><br /><br />
                                            <p className='form-inline'>
                                                <label>Service Period</label>&emsp;
                                                <input style={{ marginLeft: '60px' }} type={'text'} className='form-control'></input>
                                            </p>
                                            <p className='form-inline'>
                                                <label>80% of Gratuity</label>&emsp;
                                                <input style={{ marginLeft: '50px' }} type={'text'} className='form-control'></input>
                                            </p><br /><br />
                                            <p className='form-inline'>
                                                <label>Total Installment</label>&emsp;
                                                <input style={{ marginLeft: '50px' }} type={'text'} className='form-control'></input>
                                            </p>
                                        </div>
                                    </div>
                                    <div className='row'>
                                        <div className='form-inline m-4'>
                                            <label>Reason :</label>&emsp;

                                            <input style={{ marginLeft: '70px', width: '85%' }} type={'text'} className='form-control'></input>
                                        </div><br />
                                        <div className='bg-light'>
                                            <label>Previous Loan History</label>
                                            <div className='container-fluid'>
                                                <div className='row'>
                                                    <div className='col-lg-6'>
                                                        <p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <label>Loan Start Month</label>
                                                            <label>Loan End Month</label>
                                                            <label>Amount</label>
                                                            <label>Remarks</label>
                                                        </p>
                                                        <p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '90px' }} className='form-control' type={'text'}></input>
                                                        </p>
                                                        <p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '90px' }} className='form-control' type={'text'}></input>
                                                        </p>
                                                        <p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '90px' }} className='form-control' type={'text'}></input>
                                                        </p>
                                                        <p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '140px' }} className='form-control' type={'text'}></input>
                                                            <input style={{ width: '90px' }} className='form-control' type={'text'}></input>
                                                        </p>
                                                    </div>
                                                    <div className='col-lg-6'>
                                                        <p className='form-inline' style={{ marginTop: '40px', justifyContent: 'space-between' }}>
                                                            <label>Total Unit Budget</label>&emsp;
                                                            <input style={{ marginLeft: '55px' }} type={'text'} className='form-control'></input>
                                                        </p>
                                                        <p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <label>Consumed</label>&emsp;
                                                            <input style={{ marginLeft: '55px' }} type={'text'} className='form-control'></input>
                                                        </p><p className='form-inline' style={{ justifyContent: 'space-between' }}>
                                                            <label>Remaining</label>&emsp;
                                                            <input style={{ marginLeft: '55px' }} type={'text'} className='form-control'></input>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='row'>
                            <div className='col-lg-6'></div>
                            <div className='col-lg-6'>
                                <p style={{ display: 'flex', justifyContent: 'space-around' }}>
                                    <button type="button" class="btn btn-success" value={'submit'}>Submit</button>
                                    <button type="button" class="btn btn-secondary" value={'reset'}>Clear</button>
                                    <button type="button" class="btn btn-info">Exit</button>
                                </p>
                            </div>

                        </div>

                    </div>

                </form>
            </div>
        </>

    )
}

export default LoanRequestForm