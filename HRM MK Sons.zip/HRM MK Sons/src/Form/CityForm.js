import React from 'react';
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function CityForm() {
  return (
    <form>
      <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
      <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
      <Header name1="HRM System" name2="City Registration Form" />
      <div className='container'>
        <div className='row'>
          <div className='col-lg-5'>
            <label>Country</label><br />
            <label>Province</label><br />
            <label>Distric</label><br />

          </div>
          <div className='col-lg-5'>
            <input style={{ width: "300px" }} type={'text'} /><br />
            <input style={{ width: "300px" }} type={'text'} /><br />
            <input style={{ width: "300px" }} type={'text'} /><br />


          </div>
          <div className='col-lg-2'>
            <input type={'text'} /><br />
            <input type={'text'} /><br />
            <input type={'text'} /><br />

          </div>


        </div>
        <h4>City</h4>
        <div className='row'>
          <div className='col-lg-6'>
            <label>Code</label><br />
            <label>Full name</label><br />
            <label>Short name</label><br />
            <label>Zip code</label><br />
            <label>Area Code</label><br />

          </div>
          <div className='col-lg-6'>
            <input style={{ width: "300px" }} type={'number'} /><br />
            <input style={{ width: "300px" }} type={'text'} /><br />
            <input style={{ width: "300px" }} type={'text'} /><br />
            <input style={{ width: "300px" }} type={'text'} /><br />
            <input style={{ width: "300px" }} type={'text'} /><br />
          </div>
        </div><br /><br />
        <button type="button" class="btn btn-success">Save</button>&nbsp;
        <button type="button" class="btn btn-primary">New </button>&nbsp;
        <button type="button" class="btn btn-info">Exit</button>&nbsp;


      </div>


    </form>
  )
}

export default CityForm