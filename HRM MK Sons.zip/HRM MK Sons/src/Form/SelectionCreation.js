import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function SelectionCreation() {
  return (
    <>
      <form>
        <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
        <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
        <Header name1="HRM System" name2="Section Creation Form" />
        <div className='row'>
          <div className='col-lg-4'>
            <label>Company</label><br />
            <label>Division</label><br />
            <label>Unit</label><br />
            <label>Department</label><br />
          </div>
          <div className='col-lg-4'>
            <select name="cars" id="cars">
              <option value="volvo">Volvo</option>
              <option value="saab">Saab</option>
              <option value="opel">Opel</option>
              <option value="audi">Audi</option>
            </select><br />
            <select name="cars" id="cars">
              <option value="volvo">Volvo</option>
              <option value="saab">Saab</option>
              <option value="opel">Opel</option>
              <option value="audi">Audi</option>
            </select><br />
            <input type={'text'}></input><br />
            <input type={'text'}></input><br />
          </div>
        </div>

        <h5>Section</h5>
        <div className='row'>
          <div className='col-lg-4'>
            <label>Code</label><br />
            <label>Full name</label><br />
            <label>Short name</label>
          </div>
          <div className='col-lg-4'>
            <input type={'text'}></input><br />
            <input type={'text'}></input><br />
            <input type={'text'}></input><br />
          </div>
        </div>
        <button type="button" class="btn btn-success">Save</button>&nbsp;
        <button type="button" class="btn btn-primary">New </button>&nbsp;
        <button type="button" class="btn btn-info">Exit</button>&nbsp;
      </form>
    </>

  )
}

export default SelectionCreation