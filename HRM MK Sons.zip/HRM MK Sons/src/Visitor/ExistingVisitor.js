import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function ExistingVisitor() {
    return (
        <>
            < Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Existing Visitor Form" />
            <form>

                <div className='row'>
                    <div className='col-lg-1'>
                        <h6>SR#</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>Doc no</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>VisitorN</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                    </div>
                    <div className='col-lg-1'>
                        <h6>Company</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>Vehicle</h6>
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />
                        <input style={{ width: '90px' }} type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>TypeID</h6>
                        <select className='mt-2'  ><option></option></select><br />
                        <select className='mt-2' ><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />
                        <select><option></option></select><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>Mobileno</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>NOV</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>Division</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>Unit</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>
                    <div className='col-lg-1'>
                        <h6>Department</h6>
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>

                    <div className='col-lg-1'>
                        <h6>Intime</h6>           <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />
                        <input type={'text'}></input><br />

                    </div>

                </div>

                <button type="button" class="btn btn-outline-primary mt-3">Save</button>
                <button type="button" class="btn btn-outline-primary mt-3">Clear</button>
                <button type="button" class="btn btn-outline-primary mt-3">Exit</button>

            </form>
        </>
    )
}

export default ExistingVisitor