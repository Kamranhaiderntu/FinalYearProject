import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function EmployeeStatus() {
    return (
        <>
            <form>
                <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
                <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
                <Header name1="HRM System" name2="Overtime Report" />
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-4 mt-4'>

                            <label>Division</label><br />
                            <label>Unit</label><br />
                            <label>Department</label><br />
                            <label>Section</label><br />
                            <label>Emp code</label><br />

                            <label>Type type</label><br />
                            <label>Date</label><br />



                        </div>
                        <div className='col-lg-4'>
                            <h5>From</h5>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <select>
                                <option>Permanent</option>
                            </select><br />

                            <input type={'date'}></input><br /><br />

                        </div>
                        <div className='col-lg-4'>
                            <h5>To</h5>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <select>
                                <option>Permanent</option>
                            </select><br />

                            <input type={'date'}></input><br /><br />



                        </div>

                    </div>
                    <button type="button" class="btn btn-light">Run</button>&nbsp;
                    <button type="button" class="btn btn-light">Clear</button>&nbsp;
                    <button type="button" class="btn btn-light">Exit</button>&nbsp;
                </div>

            </form>
        </>
    )
}

export default EmployeeStatus