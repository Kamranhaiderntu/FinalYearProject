import React from 'react'
import Navbar from '../Mainpage/Navbar'
import Logo from '../Mainpage/Logo'
import Header from '../Mainpage/Header'
function JobFinal() {
    return (
        <>
            <form>
                <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
                <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
                <Header name1="HRM System" name2="Finailzation of Candidate Form" />
                <label>Job Descripition</label>
                <input type={'text'}></input>
                <h5>Candidate Result Information</h5>
                <div className='row'>
                    <div className='col-lg-12'>
                        <label>Interviews</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Name</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>CNIC</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Total marks</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Total Acceptance</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Total Rejection</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Accepted Salary</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Profit</label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>Maximum Salary </label>&nbsp;&nbsp;&nbsp;&nbsp;
                        <label>HOD comment</label>&nbsp;&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>
                    <div className='col-lg-12'>
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "60px" }}></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;
                        <select><option></option></select>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} ></input>&nbsp;&nbsp;&nbsp;
                        <input type={'text'} style={{ width: "100px" }}></input>&nbsp;&nbsp;&nbsp;

                    </div>















                </div>

                <button>Save</button>
                <button>Exit</button>
            </form>
        </>
    )
}

export default JobFinal