import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function HRDovertime() {
  return (
    <>
      <form>
        <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
        <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
        <Header name1="HRM System" name2="HRD overtime Locking Form" />
        <div className='container'>
          <label>Month:</label><input type={'text'}></input><br />
          <label>Division:</label><input type={'text'}></input><input type={'text'}></input><br />
          <label>unit:</label><input type={'text'}></input><input type={'text'}></input><br />
          <label>Employee Type</label>
          <input type="radio" id="html" name="fav_language" value="HTML"></input>
          <label for="html">Permanent</label>
          <input type="radio" id="html" name="fav_language" value="HTML"></input>
          <label for="html">DailyWages</label><br /><br />
          <button type="button" class="btn btn-light">Lock overtime</button>

        </div>
      </form>


    </>
  )
}

export default HRDovertime