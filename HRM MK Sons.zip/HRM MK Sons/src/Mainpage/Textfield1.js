import React from 'react'

function Textfield1(props) {
  return (
   <form>

    
  <input type={props.date} name='name'/><br/>

                <input type={props.text1} name='name'/><br/>
                <input type={props.text2} name='name'/><br/>
                <input type={props.text3} name='name'/><br/>
                <input type={props.text4} name='name'/><br/>
                <input type={props.text5} name='name'/><br/>
                <input type={props.text6} name='name'/><br/>
                <input type={props.text7} name='name'/><br/>
                <input type={props.text8} name='name'/><br/>
                <input style={{height:"60px"}} type={props.text9} name='name'/><br/>
                <input type={props.text10} name='name'/><br/>
                <input type={props.text11} name='name'/><br/>
                <input type={props.text12} name='name'/><br/>
                <input type={props.text13} name='name'/><br/>
                <input type={props.text14} name='name'/><br/>
                <input type={props.text15} name='name'/><br/>
                <input type={props.text16} name='name'/><br/>
                <input type={props.text17} name='name'/><br/>
   </form>
  )
}

export default Textfield1