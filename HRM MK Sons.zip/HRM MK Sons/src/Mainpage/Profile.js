import React from 'react'
import Body from '../Mainpage/Body';
import Textfield from '../Mainpage/Textfield';
import Textfield1 from '../Mainpage/Textfield1';
import Text3 from '../Mainpage/Text3';
import Radiobutton from '../Mainpage/Radiobutton';
import Button from '../Mainpage/Button';
import Bottom from '../Mainpage/Bottom';
import ImageCard from '../Mainpage/ImageCard';
function Profile() {
    return (
        <>
            <div className='row'>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <Body label1="Employee Code" label2="Name" label3="Father/HusbandName" label4="Mother Name" label5="Division" label6="Unit" label7="Department" label8="Section" label9="Designation" label10="Employeement" label11="Job Status" label12="Date of Birth" label13="Religion" label14="Phone #" label15="Mobile #" label16="NTN " label17="SSN #" label18="SSN Issue Date" />

                </div>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <Textfield label20="EOBI#" label21="Granding" label22="JoiningDate" label23="Shift" label24="Gender" label25="BloodGroup" label26="EmergencyCon" label27="Provience" label28="Districs" />

                </div>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <Textfield1 date="Date" text1="text" text2="text" text3="text" text4="text" text5="text" text6="text" text7="text" text8="text" text9="text" text10="text" text11="text" text12="text" text13="text" text14="text" text15="text" text16="text" text17="text" />

                </div>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <Body label2="Extension" label3="MK Email" label4="Personal Email" label5="Old Employee Code" label6="Rest Day" label7="Marotial Status" label8="Disabilites" label9="Disability Remarks" label10="Family" label11="CNIC" label12="CNIC expire Date" label13="Father CNIC" label14="City" label15="Time Period" label16="Status " />

                </div>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <Text3 />
                </div>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <ImageCard cardimage="Images/image1.png" />

                </div>
            </div>

            <div className='row '>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <label>Temporary Address</label><br />
                    <label>Parnment Address</label><br />

                </div>

                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <form>
                        <input style={{ width: "300px" }} type={'text'} /><br />
                        <input style={{ width: "300px" }} type={'text'} /><br />
                    </form>
                </div>
                <div className='col-lg-auto col-md-auto col-sm-auto'>
                    <form>
                        <input style={{ width: "300px" }} type={'text'} /><br />
                        <input style={{ width: "300px" }} type={'text'} /><br />
                    </form>
                </div>
            </div>


            <div className='row'>
                <div className='col-lg-auto'>
                    <Radiobutton name="Local Area" radio1="yes" radio2="No" />

                </div>
                <div className='col-lg-auto'>
                    <Radiobutton name="EOBI allow" radio1="yes" radio2="No" />

                </div>
                <div className='col-lg-auto'>
                    <Radiobutton name="S Security" radio1="yes" radio2="No" />

                </div>
                <div className='col-lg-auto'>
                    <Radiobutton name="Over time" radio1="yes" radio2="No" />

                </div>
                <div className='col-lg-auto'>
                    <Radiobutton name="Vaccinted" radio1="yes" radio2="No" />

                </div>
                <div className='col-lg-auto'>
                    <label>Vaccintedcenter</label>
                    <input style={{ width: "40px" }} type={'text'} />

                </div>

            </div>
            <div className='row'>
                <div className='col-lg-auto'>
                    <Button Button1="Personal Info" Button2="Work Experience" Button3="Education" Button4="Reference" Button5="Pay Break" Button6="job conforim" Button7="Blood Realtion" Button8="Realtion SS" Button9="Replacment" Button10="Tranfer" />


                </div>

            </div>
            <Bottom />
        </>
    )
}

export default Profile