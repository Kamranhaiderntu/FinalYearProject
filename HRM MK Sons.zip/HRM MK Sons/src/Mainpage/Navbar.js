import React from 'react'
import './style.css'
import { Outlet, Link } from "react-router-dom";
function Navbar(props) {
  return (
    <>
      <nav id="navbar mainNav" className="navbar sticky-top bg-light col-lg-auto col-sm-auto col-md-auto">
        <ul>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.link1}</span> <i class="bi bi-chevron-down"></i></a>
            <ul id="navbarResponsive" className='navbar-nav mx-auto collapse navbar-collapse'>

              <li><Link to="/cityform">CityForm</Link></li>
              <li><Link to="/countryform">CountryForm</Link></li>
              <li><Link to="/departmentcr">Department Creation</Link></li>
              <li><Link to="/designation">Designation</Link></li>
              <li><Link to="/districtform">District Form</Link></li>
              <li><Link to="/divisioncr">Division Creation</Link></li>
              <li><Link to="/gradeform">Grade Form</Link></li>
              <li><Link to="/province">Province</Link></li>
              <li><Link to="/selectioncr">Selection Creation</Link></li>
              <li><Link to="/unitcr">Unit Creation</Link></li>
              <li><a href="/" class="anc">WorkFlow Creation Form</a></li>
              <li><a href="/" class="anc">WorkFlow Copy Form</a></li>
              <li><a href="/" class="anc">WorkFlow Updation Form</a></li>
              <li><a href="/" class="anc">WorkFlow Audit Approval Form</a></li>
              <li><a href="/" class="anc">WorkFlow Detail Report</a></li>
              <li><a href="/" class="anc">WorkFlow Detail Report for IT</a></li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/DropDown" class="anc"><span>{props.link2}</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to="/JobApp">Job Application Form</Link></li>
              <li class="dropdown"><Link to="/Jobcan">Job Cancellation Form</Link>

              </li>
              <li><Link to="/JobAdver">Job Advertisement Form</Link></li>
              <li><Link to="/Jobpdr">Job Position Details Report</Link></li>
              <li><Link to="/cvs">CV Submition Report</Link></li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/" class="anc"><span>{props.link3}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to="/ApplicRegForm">Application Registration Form</Link></li>
              <li><Link to="/Inoutpolicyf">In Out Policy Form</Link></li>
              <li><a href="/" class="anc">Leave Status (Directorate)</a></li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/" class="anc"><span>{props.link4}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="/" class="anc">Short Listed Candidate Form</a></li>
              <li><a href="/" class="anc">Interviewed Result Form</a></li>
              <li><Link to="/FinalizationOfCandidateForm">Finalization of Cdndidate Form</Link></li>
              <li><a href="/" class="anc">Job Offer Letter Form</a></li>
              <li><a href="/" class="anc">Trial Slip Generation Form</a></li>
              <li><a href="/" class="anc">Employee Profile - Entry Form</a></li>
              <li><a href="/" class="anc">Employee Profile - Update Form</a></li>
              <li><a href="/" class="anc">Employee Profile - Display Form</a></li>
              <li><a href="/" class="anc">Employee Entry Temp</a></li>
              <li><a href="/" class="anc">Employee Update Temp</a></li>
              <li><a href="/" class="anc">Increment History - Temp</a></li>
            </ul>
          </li>

          <li class="dropdown"><a id='navelement' href="/" class="anc"><span>{props.link6}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to="/EmployeeDetailsRP" class="anc p p-1">Employee Details Report</Link></li>
              <li><Link to="/EmployeeInfoRP" class="anc p p-1">Employee Information Report</Link></li>
              <li><Link to="/ExemptedForm" class="anc p p-1">Exempted Employee</Link></li>
              <li><a href="/" class="anc p p-1">Exempted Employee Report</a></li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Personal Loan</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><Link to="/LoanOpening" class="anc">Loan Opening Form</Link></li>
                  <li class="dropdown"><Link to="/LoanReqFo">Loan Request Form</Link></li>
                  <li class="dropdown"><Link to="/LoanRecord" class="anc">Loan Record Checking</Link></li>
                  <li class="dropdown"><a href="/" class="anc">1st Level Loan Approval</a></li>
                  <li class="dropdown"><a href="/" class="anc">2nd Level Beyond Loan Approval</a></li>
                  <li class="dropdown"><a href="/" class="anc">Loan Report (Normal)</a></li>
                  <li class="dropdown"><a href="/" class="anc">Department Loan Budgeting</a></li>
                  <li class="dropdown"><a href="/" class="anc">Loan Request (Special)</a></li>
                  <li class="dropdown"><Link to="/PersonalLoanReport" class="anc">Personal Loan Report</Link></li>
                </ul>

              </li>
              <li><a href="/" class="anc p p-1">Car / Vehicle Loan</a></li>
              <li><a href="/" class="anc p p-1">Bed / Cot Loan</a></li>
              <li><a href="/" class="anc p p-1">Employee Loan Deduction Report</a></li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Advance</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><Link to="/AdvanceBalanceOpeningForm" class="anc">Advance Balance Opening Form</Link></li>
                  <li class="dropdown"><a href="/" class="anc">Advance Record Checking</a></li>
                  <li class="dropdown"><a href="/" class="anc">Advance Request Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">1st Level Advance Approval</a></li>
                  <li class="dropdown"><a href="/" class="anc">2nd Level Beyond Advance Approval</a></li>
                  <li class="dropdown"><a href="/" class="anc">Advance Special Request</a></li>
                  <li><Link to="/AdvanceReports" class="anc">Advance Reports</Link></li>
                  <li class="dropdown"><a href="/" class="anc">Daily Wages Advance Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Daily Wages Advance Report</a></li>
                  <li class="dropdown"><Link to="/AdvanceDeduction" class="anc">Advance Deduction Report</Link></li>
                  <li class="dropdown"><Link to="/AdvanceSalary" class="anc">Employee Advance Payment Report</Link></li>
                  <li class="dropdown"><Link to="/AdvanceAudit" class="anc">Advance Report (For Audit Verification)</Link></li>
                  <li class="dropdown"><a href="/" class="anc">Advance Request Form</a></li>
                </ul>

              </li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Leave</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Leave Request</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Approval 1st and Beyond Level</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Request HRD Rights</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Deletion Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Balance Opening Form</a></li>
                  <hr className='bg bg-secondary' />
                  <li class="dropdown"><a href="/" class="anc">Leave Encashment Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Encashment Report</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Encashment Locking Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Encashment Locked Report</a></li>
                  <hr className='bg bg-secondary' />
                  <li class="dropdown"><a href="/" class="anc">Leave Reports</a></li>
                  <li class="dropdown"><a href="/" class="anc">Leave Feed Record - Audit Verification</a></li>
                </ul>

              </li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Over Time</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Over Time Prior Request Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Over Time Prior Approval Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Over Time Request Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">1st Level Ovet Time Approval Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">2nd Level Beyond Over Time Approval</a></li>
                  <li class="dropdown"><a href="/" class="anc">2nd Level Beyond Over Time Approval MAC</a></li>

                  <li class="dropdown"><a href="/" class="anc">Over Time Feeding Without Check</a></li>
                  <li class="dropdown"><a href="/" class="anc">Over Time Looking Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Over Time Report</a></li>
                  <li class="dropdown"><a href="/" class="anc">Over Time Report - Audit</a></li>
                </ul>

              </li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>CPL</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">CPL Request Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">First Level Beyond CPL Approval</a></li>
                </ul>

              </li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Salary Deduction</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><Link to="/Incometax">Income Tax</Link></li>
                  <li class="dropdown"><Link to="/IncomeTaxD">Income Tax Deduction Form</Link></li>
                  <li class="dropdown"><Link to="/Misc">Misc. Deduction Form</Link></li>
                  <li class="dropdown"><Link to="/MiscReport" class="anc">Misc. Deduction Report</Link></li>
                  <li class="dropdown"><Link to="/MessR">Mess Deduction Report</Link></li>
                </ul>

              </li>
              <li><Link to="/EmployeeCodeGener" class="anc p p-1">SAP Vendor Code - Entry Form</Link></li>
              <li><a href="/" class="anc p p-1">Employee Record Change / Transfer Form</a></li>
              <li><a href="/" class="anc p p-1">Employee Record Change / Transfer Report</a></li>
              <li><a href="/" class="anc p p-1">Employee Record Report</a></li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Increment / Decrement</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Increment Decrement Form</a></li>
                  <li class="dropdown"><Link to={'/EmployeeIncrementDecrementReport'} class="anc">Increment Decrement Report</Link></li>
                </ul>

              </li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Employee Card</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Employee Card Generation</a></li>
                  <li class="dropdown"><Link to="/CardReports" className="anc">Employee Card Report</Link></li>
                  <li class="dropdown"><Link to="/MultiCardReports" className="anc">Multi Card Holder Report</Link></li>
                  <li class="dropdown"><a href="/" class="anc">Employee BarCode Report</a></li>
                </ul>

              </li>
              <li><a href="/" class="anc p p-1">Bank Account Form</a></li>
              <li><a href="/" class="anc p p-1">Bank Account Report</a></li>
              <li><a href="/" class="anc p p-1">Bank Account Opening Information</a></li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Social Security</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Social Security Form</a></li>
                  <li class="dropdown"><a href="/" class="anc">Social Security Detailed Summary Report</a></li>
                  <li class="dropdown"><a href="/" class="anc">Monthly Reconcilation PESSI Report</a></li>
                  <li class="dropdown"><a href="/" class="anc">Social Security Reports</a></li>
                </ul>

              </li>
              <li><a href="/" class="anc p p-1">Employee Strength Form</a></li>
              <li><a href="/" class="anc p p-1">On Hold and Approved Employee Strength Report</a></li>
              <li><a href="/" class="anc p p-1">Employee Strength Report</a></li>
              <li><a href="/" class="anc p p-1">Employee Grading Report</a></li>
              <li><a href="/" class="anc p p-1">Employee Charge Report</a></li>
              <li><a href="/" class="anc p p-1">Employee Charge Sheet</a></li>
              <li><a href="/" class="anc p p-1">Employee Charge Sheet Report</a></li>
              <li><a href="/" class="anc p p-1">Attendance Report</a></li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/" class="anc"><span>{props.link7}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="/" className='p p-1'><small><b>Employee Gratuity Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee Final Settlement Bill</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Final Settlement Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Final Settlement Locking Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Resignation Entry Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Resignation Updation Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee Reinstate Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee Appoint / Left Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attendance Transfer Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attendance Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attendance Form Manual</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>In Out Adjustment Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>In Out Adjustment Without Check</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>In Out Adjustment Exempted Employees</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>In Out Adjustment for Time Office</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee Out Slip</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Final Settlement Locked Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attendance Report Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Manual In Out Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee In Out Reports</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee Attendance Report -24 hours</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Monthly Attendance Registration Generation</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employee Register Deletion</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attandance register -On House Verification</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attandance Register Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>In Out Register Audit</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Attandance Register Final By Audit</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Exempted Employees Days Updation</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Salary Generation Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Salary Sheet Permanent</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Salary Slip Permanent</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Salary Adjustment Form</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Salary Adjustment/Arrears Report</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Salary Sheet Dailywages Payroll</b></small></a></li>
              <li><a href="/" className='p p-1'><small><b>Employees Bank Accounts Salary</b></small></a></li>
              <li class="dropdown"><a href="/" class="anc p p-1"><span>Salary Allowence</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Drop Down 2</a></li>
                  <li class="dropdown"><a href="/" class="anc">Drop Down 3</a></li>
                  <li class="dropdown"><a href="/" class="anc">Drop Down 4</a></li>
                </ul>

              </li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.link8}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="/">Organizational Chart</a></li>
              <li><a href="/">Testing Attandance Data</a></li>
              <li><a href="/">List Of Unit Report</a></li>
              <li><a href="/">List Of Departments Report</a></li>
              <li class="dropdown"><a href="/" class="anc"><span>List Of Sections Report</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Drop Down 2</a></li>
                  <li class="dropdown"><a href="/" class="anc">Drop Down 3</a></li>
                  <li class="dropdown"><a href="/" class="anc">Drop Down 4</a></li>
                </ul>

              </li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.newlink}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="/">Organizational Chart</a></li>
              <li><a href="/">Testing Attandance Data</a></li>
              <li><a href="/">List Of Unit Report</a></li>
              <li><a href="/">List Of Departments Report</a></li>
              <li class="dropdown"><a href="/" class="anc"><span>List Of Sections Report</span><i class="bi bi-chevron-right">
              </i></a>
                <ul >
                  <li class="dropdown"><a href="/" class="anc">Drop Down 2</a></li>
                  <li class="dropdown"><a href="/" class="anc">Drop Down 3</a></li>
                  <li class="dropdown"><a href="/" class="anc">Drop Down 4</a></li>
                </ul>

              </li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.newlink1}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to={'/MessMembership'}>Mess Membership Form</Link></li>
              <li><Link to={'/MessGuest'}>Mess Guest Form</Link></li>
              <li><Link to={'/MessExpense'}>Mess Expense Form</Link></li>
              <li><Link to={'/MessDeducationform'}>Mess Deducation Form</Link></li>
              <li><Link to={'/MessMember'}>Mess Deducation(Member) Form</Link></li>
              <li><Link to={'/MessGuest'}>Mess Deducation(Guest) Form</Link></li>
              <li><Link to={'/DailyMess'}>DailyMess</Link></li>

            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.newlink2}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to={'/UnitOfRegistration'}>Unit of Measure Form</Link></li>
              <li><Link to={'/MedicineRegistration'}>MedicineRegistration Form</Link></li>
              <li><Link to={'/ReceiptOfMedicineForm'}>Receipt of Medicine Form</Link></li>
              <li><Link to={'/ReceiptOfMedicineReport'}>Receipt of Medicine Report</Link></li>
              <li><a href="/">Medicine Issuance Form</a></li>
              <li><a href="/">Medicine Return Form</a></li>
              <li><a href="/">Medicine Return Report</a></li>
              <li><a href="/">Daily Patient Report</a></li>
              <li><a href="/">Medicine Stock Report</a></li>


            </ul>
          </li>

          <li class="dropdown"><a id='navelement' href="/"><span>{props.link9}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="/">Change Password</a></li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.link10}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="/">Cascade</a></li>
              <li><a href="/">Tile Vertically</a></li>
              <li><a href="/">Tile Horizontally</a></li>
            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.link11}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to="/VisitorEntry">Visitor Entry Form</Link></li>
              <li><Link to="/ExistingVisitor">Existing Visitor</Link></li>
              <li><Link to="/VisitorReports">Visitor Reports</Link></li>

            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.link12}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to="/HostelReg">Hostel Register</Link></li>
              <li><Link to="/Room">Room Registration</Link></li>
              <li><Link to="/Allocation">Room Allocation</Link></li>
              <li><Link to="/HostelDetail">Hostel Detail Report</Link></li>

            </ul>
          </li>
          <li class="dropdown"><a id='navelement' href="/"><span>{props.link13}</span><i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><Link to='/Module'>Transport Modules</Link></li>
              <li><Link to='/UserRight'>User Right</Link></li>
              <li><Link to='/TransportRegion'>Transport Region</Link></li>
              <li><Link to='/TransportStop'>Transport stop</Link></li>
              <li><Link to='/TransportRoute'>Transport Route</Link></li>
              <li><Link to='/TransportCharges'>Transport Charges</Link></li>
              <li><Link to='/TransportCard'>Transport Card</Link></li>

            </ul>
          </li>

        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav>
      <Outlet />
    </>
  )
}

export default Navbar