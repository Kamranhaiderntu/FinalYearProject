import React from 'react'

function ImageCard(props) {
  return (
    <form>
      <div class="card" >
        <img class="card-img-top" src={props.cardimage} alt="Card image cap" style={{ height: "200px" }} />
        <div class="card-body">

        </div>
        <label for="formFileLg" class="form-label">Click it to Upload Image</label>
        <input class="form-control form-control-sm" id="formFileLg" type="file" />

      </div>
      <div className='row'>
        <div className='col-lg-6'>
          <label>Last IN</label><br />
          <label>Last OUT</label><br />
          <label> Address</label><br />
        </div>
        <div className='col-lg-6'>
          <input style={{ width: "80px" }} type={'text'} /><br />
          <input style={{ width: "80px" }} type={'text'} /><br />
          <input style={{ width: "80px" }} type={'text'} /><br />
        </div>
      </div>

    </form>
  )
}

export default ImageCard