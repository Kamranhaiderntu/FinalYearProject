import React from 'react'

function Textfield(props) {
  return (
 <form>

<input type={"number"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<input type={"text"}/><br/>
<div className='row'>
    <div className='col-lg-6'>
        <select style={{height:"60px"}}>
            <option><label>New Joinig</label></option>
        </select><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>
        <input style={{width:"110px"}} type={"text"}/><br/>


    </div>
    <div className='col-lg-6'>
        <label style={{height:"45px"}}>{props.label20}</label><br/>
        <label>{props.label21}</label><br/>
        <label>{props.label22}</label><br/>
        <label>{props.label23}</label><br/>
        <label>{props.label24}</label><br/>
        <label>{props.label25}</label><br/>
        <label>{props.label26}</label><br/>
        <label>{props.label27}</label><br/>
        <label>{props.label28}</label><br/>


    </div>

</div>

 </form>
  )
}

export default Textfield