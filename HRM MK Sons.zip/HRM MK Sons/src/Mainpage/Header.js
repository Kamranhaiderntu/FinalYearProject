import React from 'react'

function Header(props) {
  return (
    <div>
      <div className='bg-primary' >
        <h6>{props.name1}</h6>
        <h4 className='bg-info'>{props.name2}</h4>
        <h6 className='bg-info'>{props.name3}</h6>
      </div>
    </div>
  )
}

export default Header