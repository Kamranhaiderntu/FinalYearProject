import React from 'react'

function Text3(props) {
  return (
   <form className=' mt-4'>

 <input  type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input style={{height:"50px"}} type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
 <input type={'text'}/><br/>
   </form>
  )
}

export default Text3