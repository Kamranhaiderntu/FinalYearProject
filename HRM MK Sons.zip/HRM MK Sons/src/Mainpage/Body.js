import React from 'react';
function Body(props) {
  return (
    <div className='body'>
      <label>{props.label1}</label><br />
      <label>{props.label2}</label><br />
      <label>{props.label3}</label><br />
      <label>{props.label4}</label><br />
      <label>{props.label5}</label><br />
      <label>{props.label6}</label><br />
      <label>{props.label7}</label><br />
      <label>{props.label8}</label><br />
      <label>{props.label9}</label><br />
      <label>{props.label10}</label><br />
      <label>{props.label11}</label><br />
      <label>{props.label12}</label><br />
      <label>{props.label13}</label><br />
      <label>{props.label14}</label><br />
      <label>{props.label15}</label><br />
      <label>{props.label16}</label><br />
      <label>{props.label17}</label><br />
      <label>{props.label18}</label><br />

    </div>
  )
}

export default Body