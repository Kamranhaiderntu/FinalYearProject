import React from 'react'

function Bottom() {
  return (

    <div className='row mt-3' >
      <div className='col-lg-4'>
        <label>Personal Histroy</label>
        <div className='row'>
          <div className='col-lg-2'>
            <form>
              <label>Sr#</label><br />
              <input style={{ width: '60px' }} type={'text'} /><br />
              <input style={{ width: '60px' }} type={'text'} /><br />
              <input style={{ width: '60px' }} type={'text'} /><br />
              <input style={{ width: '60px' }} type={'text'} /><br />
              <input style={{ width: '60px' }} type={'text'} /><br />

            </form>

          </div>
          <div className='col-lg-4'>
            <form>
              <label>Designation</label><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
            </form>
          </div>
          <div className='col-lg-4'>
            <form>
              <label>Effect Data</label><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
            </form>
          </div>


        </div>

      </div>

      <div className='col-lg-8 '>
        <label>Warning letter charge sheet</label><br />
        <div className='row mt-4'>
          <div className='col-lg-2'>
            <form>
              <label>Company</label><br />
              <label>Document</label><br />
              <label>Detail</label><br />
              <label>Date</label><br />
              <label>Type</label><br />
            </form>

          </div>
          <div className='col-lg-2'>
            <form>
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
            </form>

          </div>
          <div className='col-lg-2'>
            <form>
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
            </form>

          </div>
          <div className='col-lg-2'>
            <form>
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
            </form>

          </div>
          <div className='col-lg-2'>
            <form>
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
              <input type={'text'} name='name' /><br />
            </form>

          </div>
        </div>
      </div>

    </div>
  )
}

export default Bottom