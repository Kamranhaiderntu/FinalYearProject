import React from 'react';
function Logo(props) {
  return (
    <div className='logo'>
      <img style={{ width: "70px" }} src={props.image} alt="logo" />
      <label>{props.label}</label>

    </div>
  )
}

export default Logo