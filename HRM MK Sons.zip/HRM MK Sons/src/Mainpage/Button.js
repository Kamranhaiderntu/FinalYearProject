import React from 'react'

function Button(props) {
  return (
    <div>
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true" >{props.Button1}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button2}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button3}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button4}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button5}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button6}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button7}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button8}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button9}</a>&nbsp;
      <a href="#" class="btn btn-outline-primary" role="button" aria-pressed="true">{props.Button10}</a>&nbsp;

    </div>
  )
}

export default Button