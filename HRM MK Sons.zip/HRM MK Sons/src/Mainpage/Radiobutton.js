import React from 'react'

function Radiobutton(props) {
  return (
<form>
    <label>{props.name}</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label class="form-check-label" for="flexRadioDefault1">
{props.radio1}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </label>
  <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1"/>
  <label class="form-check-label" for="flexRadioDefault1">
    {props.radio2}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  </label><br/>
</form>
  )
}

export default Radiobutton