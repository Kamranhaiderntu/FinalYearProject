import React from 'react'
import Logo from '../Mainpage/Logo'
import Header from '../Mainpage/Header'
import Navbar from '../Mainpage/Navbar'

function EmployeeCodeGen() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Employee Information Report" name3="Display Form" />
            <div className='container'>
                <div className='row'>
                    <div className='col-lg-2'>
                        <label>New Employee Code</label><br />
                        <label>Old Employee Code</label>
                    </div>
                    <div className='col-lg-4'>
                        <input type={'text'} /><br />
                        <input type={'text'} />
                    </div>
                    <div className='col-lg-4 '>
                        <div className='card card-body' style={{ width: '145px' }}><img src="Images/image1.png" style={{ width: '100px' }} /></div>

                    </div>

                </div>
                <div className='row'>
                    <div className='col-lg-2'>
                        <label>Name</label><br />
                        <label>Designation</label><br />
                        <label>Division</label><br />
                        <label>Unit</label><br />
                        <label>Department</label><br />
                        <label>Section</label><br />
                        <label>CNIC</label><br />
                    </div>
                    <div className='col-lg-4'>
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                    </div>
                </div>




            </div>
            <div className='mx-5 my-3'>
                <button className='btn btn-secondary mx-5'>Clear</button>
                <button className='btn btn-danger'>Exit</button>
            </div>
        </>
    )
}

export default EmployeeCodeGen