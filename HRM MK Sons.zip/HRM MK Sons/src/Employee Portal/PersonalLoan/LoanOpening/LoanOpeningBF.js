import { React, useState } from 'react'
import Logo from '../../../Mainpage/Logo';
import Header from '../../../Mainpage/Header';
import Navbar from '../../../Mainpage/Navbar';
import CarLoan from './CarLoan';
import CarLoanAG from './CarLoanAG';

function LoanOpeningBF() {
    const [toggleState, setToggleState] = useState(1);

    const toggleTab = (index) => {
        setToggleState(index);
    };
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header className="bg bg-primary" name2="Loan Opening Balance Form" />
            <div className="container-fluid">
                <div className="bloc-tabs">
                    <button
                        className={toggleState === 1 ? "tabs active-tabs" : "tabs"}
                        onClick={() => toggleTab(1)}
                    >
                        Car Loan
                    </button>
                    <button
                        className={toggleState === 2 ? "tabs active-tabs" : "tabs"}
                        onClick={() => toggleTab(2)}
                    >
                        Loan Against Gratuity
                    </button>
                </div>

                <div className="content-tabs">
                    <div className={toggleState === 1 ? "content  active-content" : "content"} >

                        <div className='container-fluid'>
                            <label>Date</label>
                            <CarLoan />
                        </div>
                    </div>

                    <div className={toggleState === 2 ? "content  active-content" : "content"} >
                        <div className='container-fluid bg bg-light'>
                            <label>Date</label>
                            <CarLoanAG />
                        </div>
                    </div>
                </div>
            </div>

        </>
    )
}

export default LoanOpeningBF