import React from 'react'

function CarLoan() {
    return (
        <>
            <div className='conateiner'>
                <div className='container'>
                    <div className='row bg bg-light'>
                        <div className='col-lg-4'>
                            <label>Code</label><br />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                        </div>
                        <div className='col-lg-4'>
                            <label>Amount</label><br />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                        </div>
                        <div className='col-lg-4'>
                            <label>Per Month Installment</label><br />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                        </div>
                    </div>
                    <div className='row'>
                        <div className='my-5'>
                            <button className='btn btn-success mx-2'>Upload Excel Fle</button>
                            <button className='btn btn-primary mx-2'>Save</button>
                            <button className='btn btn-secondary mx-2'>Clear</button>
                            <button className='btn btn-danger mx-2'>Exit</button>
                        </div>

                    </div>
                </div>
            </div>
        </>
    )
}

export default CarLoan