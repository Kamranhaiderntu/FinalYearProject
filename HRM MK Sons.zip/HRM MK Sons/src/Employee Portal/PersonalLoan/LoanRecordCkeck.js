import React from 'react'
import Logo from '../../Mainpage/Logo'
import Navbar from '../../Mainpage/Navbar'
import Header from '../../Mainpage/Header'

function LoanRecordCkeck() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Loan Record Checking Form" name3="Loan Information" />
            <div className='container'>
                <div className='row'>
                    <div className='col-lg-2' style={{ display: 'flex', flexDirection: 'column' }}>
                        <label>Apply Date</label>
                        <label>Application #</label>
                        <label>Employee Code</label>
                        <label>Employee Name</label>
                        <label>Division</label>
                        <label>Unit</label>
                        <label>Department</label>
                        <label>Section</label>
                        <label>Designation</label>
                        <label>Date of Appointment</label>
                        <label>Total Gratuity</label>
                    </div>
                    <div className='col-lg-5' style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-around' }}>
                        <input type={'date'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'date'} />
                        <input type={'text'} />
                    </div>
                    <div className='col-lg-5'>
                        <img class="card-img-top my-3" src='Images/image1.png' alt="Card cap" style={{ height: "200px", width: '200px' }} /><br />
                        <label>Applied Loan Amount:</label><input type={'text'} /><br />
                        <label>Service Period:</label><input type={'text'} /><br />
                        <label>80% of Gratuity:</label><input type={'text'} /><br />
                    </div>
                </div>
            </div>

        </>
    )
}

export default LoanRecordCkeck