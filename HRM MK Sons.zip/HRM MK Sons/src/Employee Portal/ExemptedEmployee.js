import React from 'react'

import Logo from '../Mainpage/Logo'
import Header from '../Mainpage/Header'
import Navbar from '../Mainpage/Navbar'


function ExemptedEmployee() {
    return (
        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Exempted Employee Form" />
            <form>
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-6' style={{ display: 'flex', flexDirection: 'column' }}>
                            <input type={'email'} required />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                            <input type={'text'} />
                        </div>
                        <div className='col-lg-6' style={{ display: 'flex', flexDirection: 'column', alignItems: 'end', marginTop: '80px' }}>
                            <div>
                                <button value={'submit'} className='btn btn-secondary'>Clear</button>
                                <button className='btn btn-success'>Add/Save</button>
                                <button className='btn btn-primary'>View All</button>
                            </div>

                        </div>
                    </div>


                </div>
                <div className='container-fluid my-2'>
                    <div className='row'>
                        <Header name2="Exempted Employeee List" />

                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>
                    <div className=''>
                        <input type={'text'} style={{ width: '60px' }} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'text'} />
                        <input type={'button'} value='Delete' />
                    </div>

                </div>
            </form>
        </>
    )
}

export default ExemptedEmployee