import React from 'react'
import Navbar from '../../Mainpage/Navbar';
import Header from '../../Mainpage/Header';
import Logo from '../../Mainpage/Logo';
function Employeecard() {
    return (
        <>
            <form>
                <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
                <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
                <Header name1="HRM System" name2="Employee Cards Report Parameters" />
                <div className='container'>
                    <div className='row'>
                        <div className='col-lg-4 mt-4'>
                            <label>Division</label><br />
                            <label>Unit</label><br />
                            <label>Department</label><br />
                            <label>Section</label><br />
                            <label>Emp code</label><br />
                            <label>Employee type</label><br />
                            <label>Card type</label><br />
                            <label>Reason</label><br />
                            <label>Date</label><br />
                        </div>
                        <div className='col-lg-4'>
                            <h5>From</h5>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <select>
                                <option>Permanent</option>
                                <option>Permanent1</option>
                                <option>Permanent2</option>
                            </select><br />
                            <select>
                                <option>Normal</option>
                                <option>Normal1</option>
                                <option>Normal2</option>
                            </select><br />
                            <select>
                                <option>New</option>
                            </select><br />
                            <input type={'date'}></input><br /><br />
                        </div>
                        <div className='col-lg-4'>
                            <h5>To</h5>
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <input type={'text'}></input><br />
                            <br /><br /><br />
                            <input type={'date'}></input><br /><br />
                        </div>
                    </div>
                    <button type="button" class="btn btn-success">Run</button>&nbsp;
                    <button type="button" class="btn btn-secondary">Clear</button>&nbsp;
                    <button type="button" class="btn btn-danger">Exit</button>&nbsp;
                </div>
            </form>
        </>
    )
}

export default Employeecard