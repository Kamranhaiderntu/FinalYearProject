import React from 'react'
import Logo from '../Mainpage/Logo'
import Navbar from '../Mainpage/Navbar'
import Header from '../Mainpage/Header'

function EmployeeDetailsRP() {
    return (

        <>
            <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
            <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
            <Header name1="HRM System" name2="Employee Details Report" name3="Parameter Form" />

            <div className='container'>
                <div className='row'>
                    <div className='col-lg-4'>
                        <label style={{ padding: '0px', margin: '0px' }} >Division</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Unit</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Department</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Section</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Designation</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Grade</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Employment type</label><br />
                        <label style={{ padding: '0px', marginTop: '0px' }} >Date of Appointment</label><br />
                    </div>
                    <div className='col-lg-4'>
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'text'} className='mx-5' />-<br />
                        <input type={'date'} className='mx-5' />-<br />
                    </div>
                    <div className='col-lg-4' style={{ alignContent: 'left' }}>
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <input type={'text'} /><br />
                        <label>(dd-mm-yy)</label>
                    </div>
                    <div className='my-3'>
                        <button className='mx-2 btn btn-success'>View Report</button>
                        <button className='mx-2 btn btn-secondary'>Clear</button>
                        <button className='mx-2 btn btn-danger'>Exit</button>
                    </div>
                </div>

            </div>
        </>
    )
}

export default EmployeeDetailsRP