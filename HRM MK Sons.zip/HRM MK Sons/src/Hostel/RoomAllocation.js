import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function RoomAllocation() {
  return (
    <>
      <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
      <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
      <Header name1="HRM System" name2="Room Allocation" />
      <form>
        <div className='container'>

          <div className='row'>
            <div className='col-lg-2'>

              <h5>Date</h5>
              <h5>Hostel Name</h5>
              <h5>Room ID</h5>
              <h5>Employee Code</h5>
              <h5>Name</h5>
              <h5>Designation</h5>
              <h5>Joining</h5>
              <h5>Leaving</h5>
            </div>
            <div className='col-lg-4'>
              <input type={'date'}></input><br />
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />
              <input type={'date'}></input><br />
              <input type={'date'}></input><br />

            </div>
            <div className='col-lg-4'>
              <div className='row'>
                <h5>SR#</h5>
                <input type={'text'}></input>
              </div>

            </div>
            <div className='col-lg-2'>
              <div class="card" style={{ width: '10rem', height: '200px' }}>
                <div class="card-body"></div>

              </div>

            </div>
          </div>
        </div>
        <button type="button" class="btn btn-outline-primary mt-3">Save</button>
        <button type="button" class="btn btn-outline-primary mt-3">Clear</button>
        <button type="button" class="btn btn-outline-primary mt-3">Exit</button>
      </form>
    </>
  )
}

export default RoomAllocation