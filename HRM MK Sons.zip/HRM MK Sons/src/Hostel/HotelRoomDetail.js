import React from 'react'
import Navbar from '../Mainpage/Navbar';
import Header from '../Mainpage/Header';
import Logo from '../Mainpage/Logo';
function HotelRoomDetails() {
  return (
    <>
      <Logo image="Images/mkson.jpg" label="Mk sons (pvt limited)" />
      <Navbar link1="Library" link2="Job Bank" link3="Admin" link4="Talent Aquistion Recuriting" link6="Employee Portal" link7="Payroll Managment" link8="Report" link9="Utilites" link10="Windows" newlink="Executive" newlink1="Mess Management" newlink2="Dispensary Management" link11="Visitor" link12="Hostel" link13="Transport" />
      <Header name1="HRM System" name2=" Hotel Room Detail" />
      <form>
        <div className='container'>
          <div className='row'>
            <div className='col-lg-4'>
              <h5>Hotel Name</h5>
              <h5>Room Id</h5>
              <h5>Employee Code</h5>
              <h5>Name</h5>
            </div>
            <div className='col-lg-4'>
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />
              <input type={'text'}></input><br />

            </div>
            <div className='col-lg-4'>
              <input type={'text'}></input><br />

            </div>

          </div>

        </div>
        <div className='row'>

          <div className='col-lg-4'>
            <input type="radio" id="html" name="fav_language" value="HTML"></input>
            <label for="html">Room Detail</label><br />

          </div>
          <div className='col-lg-4'>
            <input type="radio" id="html" name="fav_language" value="HTML"></input>
            <label for="html">Allotment</label><br />

          </div>
          <div className='col-lg-4'>
            <input type="radio" id="html" name="fav_language" value="HTML"></input>
            <label for="html">Residence Card</label><br />

          </div>

        </div>
        <button type="button" class="btn btn-outline-primary mt-3">Save</button>
        <button type="button" class="btn btn-outline-primary mt-3">Clear</button>
        <button type="button" class="btn btn-outline-primary mt-3">Exit</button>
      </form>
    </>
  )
}

export default HotelRoomDetails