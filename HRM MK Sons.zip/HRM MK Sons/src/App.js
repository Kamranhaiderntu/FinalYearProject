import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";



import Display from './Component/Display';
import CityForm from './Form/CityForm';
import CountryForm from './Form/CountryForm';
import DepartmentCreation from './Form/DepartmentCreation'
import Designationform from './Form/Designationform'
import Districtform from './Form/DistrictForm'
import DivisionCreation from './Form/DivisionCreation'
import Gradeform from './Form/Gradeform'
import Province from './Form/Provience'
import SelectionCreation from './Form/SelectionCreation'
import UnitCreation from './Form/UnitCreation'
import Jobapplication from './JobBankForm/Jobapplication';
import Jobcancellation from './JobBankForm/Jobcancellation';
import JobAdvertisement from './JobBankForm/JobAdvertisement';
import Jobpdr from './JobBankForm/Jobpdr';
import Cvsubm from './JobBankForm/Cvsubm';
import Main from './Component/Main';
import InOutPF from './Admin/InOutPF';
import LoanRequestForm from './Form/LoanRequestForm';
import Misc from './Employee Portal/SalaryDeduction/Misc';
import Incometax from './Form/Incometax';
import JobFinal from './Form/JobFinal';
import ApplicationRegForm from './Admin/JobApplicRF/ApplicationRegForm';
import PersonalLoan from './Employee Portal/PersonalLoan/PersonalLoan';
import AdvanceAudit from './Employee Portal/Advance/AdvanceAudit';
import AdvanceBalance from './Employee Portal/Advance/AdvanceBalance';
import AdvanceDeduction from './Employee Portal/Advance/AdvanceDeduction';
import AdvanceReport from './Employee Portal/Advance/AdvanceReport';
import AdvanceSalary from './Employee Portal/Advance/AdvanceSalary';
import Employeecard from './Employee Portal/EmployeeCard/Employeecard';
import MessDeducation from './Employee Portal/SalaryDeduction/MessDeducation';
import IncometaxDedcutation from './Employee Portal/SalaryDeduction/IncometaxDedcutation';
import MultiCard from './Employee Portal/EmployeeCard/MultiCard';
import Login from './Authentication/Login';
import Signup from './Authentication/Signup';
import UnitOfMeasure from './Dispensary/UnitOfMeasure';
import MedicineRegistration from './Dispensary/MedicineRegistration';
import ReceiptOfMedicine from './Dispensary/ReceiptOfMedicine';
import ReceiptOfMedicineReport from './Dispensary/ReceiptOfMedicineReport';
import MiscDeducation from './Employee Portal/SalaryDeduction/MiscDeducation';
import EmployeeIncrement from './Employee Portal/EmployeeIncrementDec/EmployeeIncrement';
import EmployeeDetailsRP from './Employee Portal/EmployeeDetailsRP';
import EmployeeInfoRP from './Employee Portal/EmployeeInfoRP';
import EmployeeCodeGen from './Employee Portal/EmployeeCodeGen';
import ExemptedEmployee from './Employee Portal/ExemptedEmployee';
import LoanOpeningBF from './Employee Portal/PersonalLoan/LoanOpening/LoanOpeningBF';
import LoanRecordCkeck from './Employee Portal/PersonalLoan/LoanRecordCkeck';
import DailyMess from './Mess/DailyMess';
import MessDeducationform from './Mess/MessDeducationform';
import MessDeducationGuest from './Mess/MessDeducationGuest';
import MessDeducationMember from './Mess/MessDeducationMember';
import MessExpense from './Mess/MessExpense';
import MessGuest from './Mess/MessGuest';
import MessMember from './Mess/MessMember';
import MessMembership from './Mess/MessMembership';
import HostelRegistration from './Hostel/HostelRegistration'
import HostelRoom from './Hostel/HostelRoomRegistration'
import HotelRoomDetails from './Hostel/HotelRoomDetail'
import RoomAllocation from './Hostel/RoomAllocation'
import ExistingVisitor from './Visitor/ExistingVisitor';
import VisitorEntryForm from './Visitor/VisitorEntryForm';
import VisitorReport from './Visitor/VisitorReport';
import Module from './Transport/Module';
import TransportCard from './Transport/TransportCard'
import Transportcharges from './Transport/Transportcharges';
import TransportRegion from './Transport/TransportRegion';
import TransportRoute from './Transport/TransportRoute';
import TransportStop from './Transport/TransportStop';
import UserRight from './Transport/UserRight';


function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Main />} />
          {/* <Route path="/" element={<Login />} /> */}
          <Route path="/signup" element={<Signup />} />
          <Route path="/display" element={<Display />} />
          <Route path="/EmployeeDetailsRP" element={<EmployeeDetailsRP />} />
          <Route path="/EmployeeInfoRP" element={<EmployeeInfoRP />} />
          <Route path="/cityform" element={<CityForm />} />
          <Route path="/countryform" element={<CountryForm />} />
          <Route path="/departmentcr" element={<DepartmentCreation />} />
          <Route path="/designation" element={<Designationform />} />
          <Route path="/districtform" element={<Districtform />} />
          <Route path="/divisioncr" element={<DivisionCreation />} />
          <Route path="/gradeform" element={<Gradeform />} />
          <Route path="/province" element={<Province />} />
          <Route path="/selectioncr" element={<SelectionCreation />} />
          <Route path="/unitcr" element={<UnitCreation />} />
          <Route path="/JobApp" element={<Jobapplication />} />
          <Route path="/Jobcan" element={<Jobcancellation />} />
          <Route path="/JobAdver" element={<JobAdvertisement />} />
          <Route path="/Jobpdr" element={<Jobpdr />} />
          <Route path="/cvs" element={<Cvsubm />} />
          <Route path="/Inoutpolicyf" element={<InOutPF />} />
          <Route path="/LoanReqFo" element={<LoanRequestForm />} />
          <Route path="/LoanRecord" element={<LoanRecordCkeck />} />
          <Route path="/ApplicRegForm" element={<ApplicationRegForm />} />
          <Route path="/Misc" element={<Misc />} />
          <Route path="/MiscReport" element={<MiscDeducation />} />
          <Route path="/MessR" element={<MessDeducation />} />
          <Route path="/IncomeTaxD" element={<IncometaxDedcutation />} />
          <Route path="/Incometax" element={<Incometax />} />
          <Route path="/MultiCardReports" element={<MultiCard />} />
          <Route path="/CardReports" element={<Employeecard />} />
          <Route path="/AdvanceAudit" element={<AdvanceAudit />} />
          <Route path="/AdvanceSalary" element={<AdvanceSalary />} />
          <Route path="/AdvanceReports" element={<AdvanceReport />} />
          <Route path="/AdvanceBalanceOpeningForm" element={<AdvanceBalance />} />
          <Route path="/AdvanceDeduction" element={<AdvanceDeduction />} />
          <Route path="/FinalizationOfCandidateForm" element={<JobFinal />} />
          <Route path="/PersonalLoanReport" element={<PersonalLoan />} />
          <Route path="/LoanOpening" element={<LoanOpeningBF />} />
          <Route path="/UnitOfRegistration" element={<UnitOfMeasure />} />
          <Route path="/MedicineRegistration" element={<MedicineRegistration />} />
          <Route path="/ReceiptOfMedicineForm" element={<ReceiptOfMedicine />} />
          <Route path="/ReceiptOfMedicineReport" element={<ReceiptOfMedicineReport />} />
          <Route path="/EmployeeIncrementDecrementReport" element={<EmployeeIncrement />} />
          <Route path="/EmployeeCodeGener" element={<EmployeeCodeGen />} />
          <Route path="/ExemptedForm" element={<ExemptedEmployee />} />
          <Route path="/DailyMess" element={<DailyMess />} />
          <Route path="/MessDeducationform" element={<MessDeducationform />} />
          <Route path="/MessDeducationGuest" element={<MessDeducationGuest />} />
          <Route path="/MessDeducationMember" element={<MessDeducationMember />} />
          <Route path="/MessExpense" element={<MessExpense />} />

          <Route path="/MessGuest" element={<MessGuest />} />
          <Route path="/MessMember" element={<MessMember />} />
          <Route path="/MessMembership" element={<MessMembership />} />
          <Route path="/HostelReg" element={<HostelRegistration />} />
          <Route path="/Room" element={<HostelRoom />} />
          <Route path="/HostelDetail" element={<HotelRoomDetails />} />
          <Route path="/Allocation" element={<RoomAllocation />} />
          <Route path="/ExistingVisitor" element={<ExistingVisitor />} />
          <Route path="/VisitorEntry" element={<VisitorEntryForm />} />
          <Route path="/VisitorReports" element={<VisitorReport />} />
          <Route path='/Module' element={<Module />} />
          <Route path='/TransportCard' element={<TransportCard />} />
          <Route path='/TransportCharges' element={<Transportcharges />} />
          <Route path='/TransportRegion' element={<TransportRegion />} />
          <Route path='/TransportRoute' element={<TransportRoute />} />
          <Route path="/TransportStop" element={<TransportStop />} />
          <Route path="/UserRight" element={<UserRight />} />


        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;

